import { NavLink } from "react-router-dom";

function Header() {
  return (
    <header className="sticky top-0 z-50 flex min-h-24 flex-col items-center justify-center gap-4 bg-violet-600 p-4 text-white shadow-md transition-all duration-300 lg:flex-row lg:justify-between lg:px-20">
      <h1 className="text-3xl font-extrabold tracking-tight">
        Favourite Student App
      </h1>
      <nav className="flex justify-center gap-8 text-lg font-medium text-nowrap text-violet-100">
        <NavLink to="/" className="transition-colors hover:text-white">
          Home
        </NavLink>
        <NavLink to="forms" className="transition-colors hover:text-white">
          Add Student
        </NavLink>
        <NavLink to="favourites" className="transition-colors hover:text-white">
          Favorite Students
        </NavLink>
      </nav>
    </header>
  );
}

export default Header;
